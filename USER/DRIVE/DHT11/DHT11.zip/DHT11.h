#ifndef __DHT11_H_
#define __DHT11_H_
#include "stm32f10x.h"
unsigned char DHT11_ReadTempAndHumi(void);
#endif
